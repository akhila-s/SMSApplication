package com.example.akhila.smsapplication;

import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Telephony;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


public class Inbox extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inbox);
        new FillInbox().execute();
    }

    class FillInbox extends AsyncTask<Void, Void, ArrayList<String>> {

        @Override
        protected ArrayList<String> doInBackground(Void... params) {
            ArrayList<String> smsMap = new ArrayList<String>();

            /*if (!(ContextCompat.checkSelfPermission(getBaseContext(), "android.permission.READ_SMS") == PackageManager.PERMISSION_GRANTED)) {
                final int REQUEST_CODE_ASK_PERMISSIONS = 123;
                ActivityCompat.requestPermissions(Inbox.this, new String[]{"android.permission.READ_SMS"}, REQUEST_CODE_ASK_PERMISSIONS);
            }*/

            Cursor cursor = getContentResolver().query(Uri.parse("content://sms/inbox"), null, null, null, null);
            while (cursor.moveToNext()){
                String phoneNumber = cursor.getString(cursor.getColumnIndex(Telephony.Sms.ADDRESS));
                String messageText = cursor.getString(cursor.getColumnIndex(Telephony.Sms.BODY));
                smsMap.add(phoneNumber+"\n"+messageText);
            }
            return smsMap;
        }

        @Override
        protected void onPostExecute(ArrayList<String> smsMap) {
            super.onPostExecute(smsMap);
            ListView smsView = (ListView)findViewById(R.id.sms_list);
            if(smsMap.size() != 0) {
                smsView.setAdapter(new ArrayAdapter<String>(getApplicationContext(), R.layout.text, smsMap));
            }
            else{
                Toast.makeText(getApplicationContext(),"Inbox Empty",
                        Toast.LENGTH_LONG).show();
            }
        }
    }
}
