package com.example.akhila.smsapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button compose_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                compose_activity(view);
            }
        });

        Button inboxBtn = (Button)findViewById(R.id.inbox_btn);
        inboxBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                goToInbox();
            }
        });

        Bundle extras = getIntent().getExtras();
        if(extras != null){
            String messageToShow = extras.getString("toast");
            Toast.makeText(getApplicationContext(),messageToShow,
                    Toast.LENGTH_LONG).show();
        }
    }

    public void goToInbox(){
        Intent inboxIntent = new Intent(this, Inbox.class);
        startActivity(inboxIntent);
    }

    public void compose_activity(View view) {
        Intent intent = new Intent(this, ChooseContact.class);
        Log.e("1","In Compose Method");
        startActivity(intent);
    }
}
