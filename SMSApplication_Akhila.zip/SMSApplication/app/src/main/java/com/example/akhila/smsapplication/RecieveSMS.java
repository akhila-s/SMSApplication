package com.example.akhila.smsapplication;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;

public class RecieveSMS extends BroadcastReceiver{

    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle bundle = intent.getExtras();
        SmsMessage[] messages = null;
        String smsText = "";
        if(bundle != null){
            Object[] pDus = (Object[])bundle.get("pdus");
            messages = new SmsMessage[pDus.length];
            for (int i = 0;i < pDus.length;i++){
                messages[i] = SmsMessage.createFromPdu((byte[])pDus[i]);
                smsText += messages[i].getOriginatingAddress()+" : "+messages[i].getMessageBody().toString();
                Log.e(i+"", smsText);
            }
        }
    }
}
