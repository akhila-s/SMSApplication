package com.example.akhila.smsapplication;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class ChooseContact extends AppCompatActivity {

    HashMap<String,String> Contacts = new HashMap<>();
    Map<String, String> sortedContacts;
    ListView listview;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compose_sms);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        listview = (ListView) findViewById(R.id.listview);
        final GetContacts getcontacts = new GetContacts();
        getcontacts.execute();

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selected = ((TextView) view.findViewById(R.id.textview)).getText().toString();
                System.out.println(selected+"[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[");
                System.out.println("//////////////////////////////"+position);
                String num = "";
                if(sortedContacts.containsKey(selected)) {
                    num = sortedContacts.get(selected);
                }


                Toast toast = Toast.makeText(getApplicationContext(), num, Toast.LENGTH_SHORT);
                toast.show();

                Intent i = new Intent(getApplicationContext(),SendSMS.class);
                i.putExtra("number",num);
                startActivity(i);

            }
        });
    }



    class GetContacts extends AsyncTask<Void, Void, ArrayList<String>> {

        ArrayList<String> contacts = new ArrayList<String>();
        ArrayList<String> numbers = new ArrayList<String>();


        @Override
        protected ArrayList<String> doInBackground(Void... params) {


            if (!(ContextCompat.checkSelfPermission(getBaseContext(), "android.permission.READ_CONTACTS") == PackageManager.PERMISSION_GRANTED)) {
                final int REQUEST_CODE_ASK_PERMISSIONS = 123;
                ActivityCompat.requestPermissions(ChooseContact.this, new String[]{"android.permission.READ_CONTACTS"}, REQUEST_CODE_ASK_PERMISSIONS);
            }


            Cursor cursor = getContentResolver().query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
                    null, null, null);
            while (cursor.moveToNext()) {

                String contactName = cursor
                        .getString(cursor
                                .getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                String number = cursor
                        .getString(cursor
                                .getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                if(!(Contacts.containsKey(contactName))) {
                    Contacts.put(contactName, number);
                    contacts.add(contactName);
                    numbers.add(number);
                }
            }
            cursor.close();
            Collections.sort(contacts, new IgnoreCase());
            sortedContacts = new TreeMap<String, String>(Contacts);
            System.out.println("--------------------------------------"+contacts);
            return contacts;
        }

        public class IgnoreCase implements Comparator<String> {
            public int compare(String s1, String s2) {
                return s1.toLowerCase().compareTo(s2.toLowerCase());
            }
        }

        @Override
        protected void onPostExecute(ArrayList<String> contacts) {
            super.onPostExecute(contacts);
//            ArrayAdapter<String> adapter = new ArrayAdapter<String>(
//                    getApplicationContext(), R.layout., contacts);

            // listview.setAdapter(adapter);
            //String[] lv_arr = {};

            listview.setAdapter(new ArrayAdapter<String>(getApplicationContext(),
                    R.layout.text, contacts));


        }
    }
}
