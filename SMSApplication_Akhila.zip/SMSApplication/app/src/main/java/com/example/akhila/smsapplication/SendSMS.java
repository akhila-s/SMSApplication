package com.example.akhila.smsapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SendSMS extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_sms);
        EditText phoneEditor = (EditText) findViewById(R.id.phonenumber);
        Bundle extras = getIntent().getExtras();
        if(extras != null) {

            final String phoneNumber = extras.getString("number");
            phoneEditor.setText(phoneNumber);

            EditText msgEditor = (EditText) findViewById(R.id.message_text);
            final String messageText = msgEditor.getText().toString();

            Button sendBtn = (Button) findViewById(R.id.send_btn);

            sendBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sendSMS(phoneNumber, messageText);
                }
            });
        }
    }

    public void sendSMS(String phoneNo, String messageText) {
        Intent intent = new Intent(this, MainActivity.class);
        try {
//            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNo, null, messageText, null, null);
            intent.putExtra("toast", "Message Sent");
        } catch (Exception ex) {
            intent.putExtra("toast", ex.getMessage().toString());
            ex.printStackTrace();
        }
        finally {
            startActivity(intent);
        }
    }
}
